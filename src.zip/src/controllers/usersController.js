import usersRepository from "../repositories/usersRepository.js"

const usersController = { 
    async get() {
        return await usersRepository.get()
    },
    async post(request) {
        const {name, age, email, password} = request.body
        return await usersRepository.post(name, age, email, password)
    },
    async put(request) {
        const {id, name, age, email, password} = request.body
        return await usersRepository.put(id, name, age, email, password)
    },
    async delete(request) {
        const {id} = request.body
        return await usersRepository.delete(id)
    }
}

export default usersController