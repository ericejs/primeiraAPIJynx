import Fastify from 'fastify'
import usersRoutes from "./routes/usersRoutes.js"

const fastify = Fastify({
  logger: true
})

await fastify.register(usersRoutes, { prefix: '/users' })

// let users = [
//         { nome: 'Eric', idade: 34}, 
//         { nome: 'Eloá', idade: 30}   
//     ]

// fastify.get('/get', async (request, reply) => { 
//     return users
// })



// fastify.post('/post', async (request, reply) => { 
//     const novoUsuario = {
//         name: "Eric", 
//         idade: 34
//     }
//     users.push(novoUsuario)
//     return { message: 'Usuário adicionado com sucesso', 
//              user: novoUsuario 
//     }
// })
// /**
//  * Run the server!
//  */
const start = async () => {
  try {
    await fastify.listen({ port: 3000 })
  } catch (err) {
    fastify.log.error(err)
    process.exit(1)
  }
}
start()

